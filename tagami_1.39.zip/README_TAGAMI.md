TAGAMI by Soundtemple
https://tagami.au
https://soundtemple.au/tagami

Thanks for downloading Tagami.

Tagami helps DJs, crate diggers and playlist perfectionists
organise their music libraries, so they can find the right
tune at the right time. Tag editor, music player, playlist
creator and library manager in one, connected to djay Pro,
Rekordbox, Serato, Traktor, VirtualDJ, Music.app and your
music folders.

WHAT'S IN THIS ZIP
------------------
  Installer for macOS     (tagami .dmg)
  Installer for Windows   (tagami .msi)

SYSTEM REQUIREMENTS
-------------------
  macOS:    macOS 10.15 (Catalina) or later, Apple Silicon or Intel
  Windows:  Windows 10 or 11, 64-bit

INSTALLING ON macOS
-------------------
  1. Double-click the tagami .dmg to open it.
  2. Drag tagami into the Applications folder.
  3. Open tagami from Applications or Launchpad.

INSTALLING ON WINDOWS
---------------------
  1. Double-click the tagami .msi.
  2. If Windows shows "Windows protected your PC", click
     "More info", then "Run anyway".
  3. Follow the steps.
  4. Open tagami from the Start menu.

USING TAGAMI
------------
  Tagami works with local music files (not streaming services).
  Point it at your music folders, or switch on the DJ apps you
  use in Settings, and your playlists appear in the playlist
  panel.

  For help, click the help button at the top right of the app,
  or watch the video manual:
    https://www.youtube.com/@tagami-dj

LICENCE
-------
  Tagami Free is free to use, with no time limit and no limit
  on saves. Tagami Pro unlocks the bulk actions, cue editing
  and other Pro features. Buy once, and it's yours to keep.

    Buy:  https://shop.tagami.au or https://soundtemple.au/tagami

  Enter your licence key in the Account panel inside Tagami.

UNINSTALLING
------------
  macOS:    Drag tagami from Applications to the Trash.
  Windows:  Settings > Apps > Installed apps > tagami > Uninstall.

SUPPORT
-------
https://tagami.au/faq

(c) Soundtemple. All rights reserved.
