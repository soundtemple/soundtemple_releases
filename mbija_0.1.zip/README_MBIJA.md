MBIJA by Soundtemple
https://soundtemple.au

Thanks for downloading Mbija.

WHAT'S IN THIS ZIP
------------------
  Installer for macOS
  Installer for Windows

SYSTEM REQUIREMENTS
-------------------
  macOS:    macOS 11 (Big Sur) or later, Apple Silicon or Intel
            Formats: VST3, Audio Unit (AU), CLAP
  Windows:  Windows 10 or 11, 64-bit
            Formats: VST3, CLAP

INSTALLING ON macOS
-------------------
  1. Double-click the mbija .dmg to open it.
  2. Double-click "MBIJA Installer.pkg" and follow the steps.
     Click "Customize" if you only want some of the formats.
  3. Restart your DAW, or rescan your plugins.

  The plugins are installed to:
    /Library/Audio/Plug-Ins/VST3/MBIJA.vst3
    /Library/Audio/Plug-Ins/Components/MBIJA.component
    /Library/Audio/Plug-Ins/CLAP/MBIJA.clap

INSTALLING ON WINDOWS
---------------------
  1. Double-click the mbija .exe.
  2. If Windows shows "Windows protected your PC", click
     "More info", then "Run anyway".
  3. Follow the steps. You can choose VST3, CLAP or both.
  4. Restart your DAW, or rescan your plugins.

  The plugins are installed to:
    C:\Program Files\Common Files\VST3\MBIJA.vst3
    C:\Program Files\Common Files\CLAP\MBIJA.clap

USING MBIJA
-----------
  Mbija is a MIDI effect: it makes MIDI notes rather than sound.
  Put it before an instrument on the same track, or send its
  MIDI output to an instrument track. In Logic Pro, load it from
  a track's MIDI FX slot (Audio Units > Soundtemple > MBIJA).

LICENCE
-------
  Mbija runs as a free 14-day trial with everything unlocked.
  After the trial, a licence key keeps it working. Buy once,
  and it's yours to keep.

    Buy:  https://shop.soundtemple.au

  Enter your licence key in Mbija's licence panel. Moving to a
  new computer? Deactivate Mbija in the licence panel on the old
  one first.

UNINSTALLING
------------
  macOS:    Delete the three files listed under "Installing on
            macOS".
  Windows:  Settings > Apps > Installed apps > MBIJA > Uninstall.

SUPPORT
-------
https://soundtemple.au/info/contact

(c) Soundtemple. All rights reserved.
